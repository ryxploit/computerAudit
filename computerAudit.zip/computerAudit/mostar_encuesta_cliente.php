<!DOCTYPE html>
<html>
<head>
	<title>Encuestas</title>
</head>
<body>
<h1 align="center">RESULTADO DE ENCUESTA 1</h1>
<a href="administrador.php">salir</a>
<?php 
include 'conexion.php'; 
$sql6 = ("SELECT * FROM encuesta1");
$re = mysql_query($sql6);
echo "<form name='ejecuta' method='post' action='ejecuta.php'>";
echo "      
       <center> <table  border = 3 cellspadding = 3  cellspadding = 3>
            <tr>
            <th>id</th>
            <th>Nombre</th>
            
            <th>Ver encuesta</th>
            <th>Eliminar</th>
		    </tr> ";
while ($arreglo = mysql_fetch_array($re)) {
	
         
             echo "<tr>";
				    	echo "<td>$arreglo[0]</td>";
				    	echo "<td>$arreglo[1]</td>";
				    	
			echo "<td><center><a href='ver_encuesta_admin.php?id=$arreglo[0]'><img src='imagenes/encuesta.png' class='img-rounded'></center></td>"; 

			echo " <td><center><a href='moescuesta.php?id=$arreglo[0]&idborrar=3'><img src='imagenes/encuesta_borrar.png' /></a></center></td></tr>";
  }
		   

echo "</table></center>";
extract($_GET);
					if(@$idborrar==3){
		
						$sqlborrar="DELETE FROM encuesta1 WHERE idencuesta1=$id";
						$resborrar=mysql_query($sqlborrar);
						echo '<script>alert("REGISTRO ELIMINADO")</script> ';
						
						echo "<script>location.href='moescuesta.php'</script>";
					}                 

 ?>
 
</body>
</html>