<?php 
$db = "maestra";
	$host = "localhost";
	$pw = "";
	$user = "root";

	$con = mysql_connect($host,$user,$pw) or die("mala conexion de bd");
    mysql_select_db($db,$con) or die("no se puede conectar ala db");


 ?>