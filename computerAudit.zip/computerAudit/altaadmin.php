<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="cssAltaAdmin/admin.css">
	<meta charset="utf-8">
	<title>Registro de administraadores</title>
</head>
<body>
<h1 style="text-align: center; margin-bottom: 64px;">REGISTRO DE ADMINISTRADORES</h1>
<form action="guardaradmin.php" method="POST">
	<label>Nombre</label>
	<input type="text" name="nombre">
	<br>
	<label>Apellido</label>
	<input type="text" name="apellido">
	<br>
	<label>Usuario</label>
	<input type="text" name="usuario">
	<br>
	
	<br>
	<label>Contraseña Administrador</label>
	<input type="password" name="admincontra" id="password5">
	<label style="display: inline;">Ver Contraseña</label>
	<input style="width: 10%; margin-top: 5px; margin-bottom: 26px;" type="checkbox" onchange="document.getElementById('password5').type = this.checked ? 'text' : 'password'">
	<br>
	<label>Fecha</label>
	<input type="date" name="fecha" value="<?php echo date("Y-m-d"); ?>">
	<br>
	<input type="submit" name="gu" value="Guardar">

</form>
</body>
</html>