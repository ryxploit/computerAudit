<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php 
include 'conexion.php';

$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$usuario = $_POST['usuario'];
$au = $_POST['contraaudi'] ;
$fecha = $_POST['fecha'];

$sql13="INSERT INTO login(nombre,apellido,usuario,contraaudi,fecha) VALUES ('$nombre','$apellido','$usuario','$au',
                                                                                             '$fecha')";

 $ejecutar = mysql_query($sql13);

 if (!$ejecutar) {
                   echo '<script>alert("hubo un error")</script>';
                         }
  else {
                   echo '<script>alert("REGISTRO GUARDADO")</script>';
                   echo "<script>location.href='administrador.php'</script>";
                  

                   }
                                                                                                                                                                                         
 ?>
</body>
</html>