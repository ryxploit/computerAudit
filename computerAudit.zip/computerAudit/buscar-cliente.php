<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php  
include 'conexion.php';
$buscar=$_POST['buscar'];
$sql6 = ("SELECT * FROM encuesta1 WHERE nombre = '$buscar'");
$re = mysql_query($sql6);

echo "      
       <center> <table  border = 3 cellspadding = 3  cellspadding = 3 width='40%'>
            <tr bgcolor='#cccccc'>
            <th>Id</th>
            <th>Nombre</th>
            <th>resutado</th>
            
            
		    </tr> ";
while ($arreglo = mysql_fetch_array($re)) {
	
         
             echo "<tr bgcolor='#d9edf7'>";
				    	echo "<td>$arreglo[0]</td>";
				    	echo "<td>$arreglo[1]</td>";
				    	echo "<td><a href='suma2.php'>ir</a></td>";
			
  }
		   

echo "</table></center>"; 

?>

</body>
</html>