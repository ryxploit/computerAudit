<?php 

session_start();
	include 'conexion.php';
	$username=$_POST['usuario'];
	$pass=$_POST['contra'];


	//condicion de logeo de admin
	$sql2=mysql_query("SELECT * FROM login WHERE usuario='$username'");
	if($f2=mysql_fetch_assoc($sql2)){
		if($pass==$f2['admincontra']){
			$_SESSION['idusuario']=$f2['idusuario'];
			$_SESSION['usuario']=$f2['usuario'];
			

			echo '<script>alert("BIENVENIDO ADMINISTRADOR")</script> ';
			echo "<script>location.href='admin.php'</script>";
		
		}
	}
    //condicion de logeo de auditor
	$sql3=mysql_query("SELECT * FROM login WHERE usuario='$username'");
	if($f3=mysql_fetch_assoc($sql3)){
		if($pass==$f3['contraaudi']){
			$_SESSION['idusuario']=$f3['idusuario'];
			$_SESSION['usuario']=$f3['usuario'];
			

			echo '<script>alert("BIENVENIDO AUDITOR ") </script> ';
			echo "<script>location.href='auditore.php'</script>";
		
		}
	}

    //condicion de loggeo de clintes normales
	$sql=mysql_query("SELECT * FROM login WHERE usuario='$username'");
	if($f=mysql_fetch_assoc($sql)){
		if($pass==$f['contra']){
			$_SESSION['idusuario']=$f['idusuario'];
			$_SESSION['usuario']=$f['usuario'];
			

			header("Location: cliente.php");
		}else{
			echo '<script>alert("CONTRASEÑA INCORRECTA")</script> ';
		
			echo "<script>location.href='cliente.php'</script>";
		}
	}else{
		
		echo '<script>alert("ESTE USUARIO NO EXISTE, PORFAVOR REGISTRESE PARA PODER INGRESAR")</script> ';
		
		echo "<script>location.href='index.php'</script>";	

	}

















 ?>