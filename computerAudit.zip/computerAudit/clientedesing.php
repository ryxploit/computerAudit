<!DOCTYPE html>

 
<html>
<head>
	<meta charset="utf-8">
	<title>Auditoria informatica</title>
	<link rel="stylesheet" type="text/css" href="cssCliente/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="cssCliente/cliente.css">

	<link rel="stylesheet" href="fonts.css">
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
<style type="text/css">
  .ho{
    margin-bottom: 20px;padding: 4px;box-sizing: border-box;border: 1px solid #ccc;width: 10%;
background-color: #538C89;color: #FFF; 
  }
  .ho:hover{
     background-color: #024959;
  }
</style>    
  

	<meta name="viewport" content="width=device-width, initial-scale=1">


<body>
   <div class="col-md-12">
      <div class=" col-md-12 nonePadding nonePadding2">
      	   <div class="col-md-12 fondo icon">
      	   		<div class="col-md-3 icono"><img src="imagenes/logo01.png"></div>
      	   		<div class="col-md-2 title">
      	   			<a href="#" class="link titulo"><strong>Auditoria Informatica</strong></a>
      	   		</div>
      	   		<div class="col-md-5"></div>
      	   		<div class="col-md-2 socialicon">
      	   			<div class="col-md-3 social">
      	   				<a href="http://facebook.com" class="icon-button facebook"><i class="icon-facebook"></i><span></span></a>
      	   			</div>
      	   			<div class="col-md-3">
      	   				<a href="http://twitter.com/minimalmonkey" class="icon-button twitter"><i class="icon-twitter"></i><span></span></a>
      	   			</div>
      	   			<div class="col-md-3">
      	   				<a href="http://plus.google.com" class="icon-button google-plus"><i class="icon-google-plus"></i><span></span></a>
      	   			</div>
      	   			<div class="col-md-3">
      	   				<a src="instagram.png" class="icon-button instagram"><i class="icon-instagram"></i><span></span></a>
      	   			</div>
      	   		</div>
      	   		<!--<div class="col-md-4 field">
      	   			<div class="col-md-3 uno">
      	   				
      	   			</div>
      	   			<div class="col-md-7 clear_pad">
      	   				<input class="form-control input" placeholder="Buscar"></input>
      	   			</div>
      	   			<div class="col-md-2 clear_pad"><button class="btn btn2">Buscar</button></div>
      	   		</div>-->
      	   </div>
      	</div>
      	   
      	<div class="col-md-12 icon2">
      		<div class="col-md-8 div_move">
				<ul class="nav">
					<div class="col-md-3 uls">
						<li><a href="indexAuditoriaInformatica.html"><span class="icon-info"></span>Auditoría Informática</a></li>
					</div>
					<div class="col-md-2 uls">
						<li><a href="contacto.html"><span class="icon-envelop"></span>Contacto</a></li>
					</div>
					<div class="col-md-3 uls">
						<li><a href="NUESTRAEMPRESA.HTML"><span class="icon-earth"></span>¿Quiénes Somos?</a></li>
					</div>
				</ul>
			</div>
			<div class="col-md-2 div_move"></div>
      	   	<div class="col-md-2 login">
      	   		<li><a href="cerrar_session.php">Bienvenido <?php echo $_SESSION['usuario'];?></a>
                     <ul>
                        <li><a href="cerrar_session.php">Cerrar sesion</a></li> 
                     </ul>
                 </li>
      	   	</div>
		</div>
</div>

	<div class="col-md-12 "></div>
   	<div class="col-md-12">
   		<div class="col-md-2"></div>
   		<div class="col-md-8 nonePadding">
   			<div class="col-md-12 border shadow" style="bottom: auto;margin-bottom: 46px; ">
   				<label class="lal">Bienvenido Cliente </label>
   			</div>
   			
   	


<div align="center" >
<h1><strong> Buscar auditoria</strong></h1>
<form action="" method="POST">
<input type="text" style="width: 50%;" name="buscar" required placeholder="Ingrese su nombre o el de la empresa" />

<input class="ho" type="submit" value="Buscar" />
</form>
</div>
<br>
<br>

<?php  

include 'conexion.php';
$buscar = isset($_POST['buscar']) ? $_POST['buscar'] : null;
$sql6 = ("SELECT * FROM encuesta1 WHERE nombre = '$buscar'");
$re = mysql_query($sql6);

echo "      
       <center> <table  border = 3 cellspadding = 3  cellspadding = 3 width='40%'>
            <tr bgcolor='#cccccc'>
            <th><center>Id</center></th>
            <th><center>Auditor</center></th>
            <th><center>Nombre </center></th>
            <th><center>Resultado </center></th>
           
            
            
        </tr> ";
while ($arreglo = mysql_fetch_array($re)) {
  
         
             echo "<tr bgcolor='#d9edf7'>";
              echo "<td><center>$arreglo[0]</center></td>";
              echo "<td><center>$arreglo[1]</center></td>";
              echo "<td><center>$arreglo[2]</center></td>";
              echo "<td><center><a onclick='mostrar()' >ver</a></center></td>";
      
      
  }
       

echo "</table></center>"; 

?>
