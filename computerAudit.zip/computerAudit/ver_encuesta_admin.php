<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="cssVerEncuesta_admin/verEncuesta_admin.css">
<meta charset="utf-8">
	<title></title>
</head>
<body>
<?php
		extract($_GET);
		require("conexion.php");

		$sql="SELECT * FROM encuesta1 WHERE idencuesta1=$id";
	
		$ressql=mysql_query($sql);
		while ($row=mysql_fetch_row ($ressql)){
		    	$id=$row[0];
		    	$auditor=$row[1];
		    	$nombre=$row[2];
		    	$p1_1=$row[3];
		    	$p2_1=$row[4];
		    	$p3_1=$row[5];
		    	$p4_1=$row[6];
		    	$p5_1=$row[7];
		    	$p6_1=$row[8];
		    	$p7_1=$row[9];
		    	$p8_1=$row[10];
		    	$p9_1=$row[11];
		    	$p10_1=$row[12];
		    	$p11_1=$row[13];
		    	$p12_1=$row[14];
		    	$p13_1=$row[15];
		    	$p14_1=$row[16];
		    	$p15_1=$row[17];
		    	
		    }



		?>
<form action="mostar_encuesta_admin.php" method="POST">
						Id<br><input class="no" type="text" name="id" value= "<?php echo $id ?>" readonly="readonly"><br>
                         <label>Auditor: </label>
						<input class="no" type="text" name="auditor" value="<?php echo $auditor ?>">
                         <br>
						<label>Nombre: </label>
						<input class="no" type="text" name="nombre" value="<?php echo $nombre ?>">
                         <br>
						<label>1. ¿El lugar donde se ubica el centro de cómputo esta seguro de inundaciones, robo o
					cualquier otra situación que pueda poner en peligro los equipos?</label><br>
					<input type="radio" name="p1_1" value="3.8" <?php if ($p1_1 == '3.8') { echo "checked"; } ?>> Si
					<input type="radio" name="p1_1" value="0" <?php if ($p1_1 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>2. ¿El centro de cómputo da hacia el exterior?</label><br>
					<input type="radio" name="p2_1" value="3.3" <?php if ($p2_1 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p2_1" value="0" <?php if ($p2_1 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>3. ¿El material con que esta construido el centro de cómputo es confiable?</label><br>
					<input type="radio" name="p3_1" value="3.3" <?php if ($p3_1 == '3.3') { echo "checked"; } ?> > Si
					<input type="radio" name="p3_1" value="0" <?php if ($p3_1 == '0') { echo "checked"; } ?> > No<br>
					<br>
					<label>4. ¿Dentro del centro de cómputo existen materiales que puedan ser inflamables o
					causar algún daño a los equipos?</label><br>
					<input type="radio" name="p4_1" value="3.3" <?php if ($p4_1 == '3.3') { echo "checked"; } ?>  > Si
					<input type="radio" name="p4_1" value="0" <?php if ($p4_1 == '0') { echo "checked"; } ?> > No<br>
					<br>
					<label>5. ¿Existe lugar suficiente para los equipos?</label><br>
					<input type="radio" name="p5_1" value="3.3" <?php if ($p5_1 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p5_1" value="0" <?php if ($p5_1 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>6. ¿Aparte del centro de cómputo se cuenta con algún lugar para almacenar otros
					equipos de cómputo, muebles, suministros, etc.?</label><br>
					<input type="radio" name="p6_1" value="3.3" <?php if ($p6_1 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p6_1" value="0" <?php if ($p6_1 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>7. ¿Se cuenta con una salida de emergencia?</label><br>
					<input type="radio" name="p7_1" value="3.3" <?php if ($p7_1 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p7_1" value="0" <?php if ($p7_1 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>8. ¿Existen señalamientos que las hagan visibles?</label><br>
					<input type="radio" name="p8_1" value="3.3" <?php if ($p8_1 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p8_1" value="0" <?php if ($p8_1 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>9. ¿Es adecuada la iluminación del centro de cómputo?</label><br>
					<input type="radio" name="p9_1" value="3.3" <?php if ($p9_1 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p9_1" value="0" <?php if ($p9_1 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>10. ¿El color de las paredes es adecuado para el centro de cómputo?</label><br>
					<input type="radio" name="p10_1" value="3.3" <?php if ($p10_1 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p10_1" value="0" <?php if ($p10_1 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>11. ¿Existen lámparas dentro del centro de cómputo?</label><br>
					<input type="radio" name="p11_1" value="3.3" <?php if ($p11_1 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p11_1" value="0" <?php if ($p11_1 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>12. ¿Es suficiente la iluminación del centro de cómputo?</label><br>
					<input type="radio" name="p12_1" value="3.3" <?php if ($p12_1 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p12_1" value="0" <?php if ($p12_1 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>13. ¿La temperatura a la que trabajan los equipos es la adecuada de acuerdo a las
					normas bajo las cuales se rige?</label><br>
					<input type="radio" name="p13_1" value="3.3" <?php if ($p13_1 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p13_1" value="0" <?php if ($p13_1 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>14. ¿Están limpios los ductos del aire acondicionado?</label><br>
					<input type="radio" name="p14_1" value="3.3" <?php if ($p14_1 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p14_1" value="0" <?php if ($p14_1 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>15. ¿La ubicación de los aires acondicionado es adecuada?</label><br>
					<input type="radio" name="p15_1" value="3.3" <?php if ($p15_1 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p15_1" value="0" <?php if ($p15_1 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<input href="mostar_encuesta_cliente.php" class="bo" type="submit" name="" value="Regresar">

</form>

</body>
</html>