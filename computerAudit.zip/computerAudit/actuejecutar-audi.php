<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php


extract($_POST);	
	require("conexion.php");
	$sentencia="update cliente set nombre='$nombre', apellido='$apellido', usuario='$usuario', contrasena='$contra', fecha='$fecha' where idusuario='$id'";
	
	$resent=mysql_query($sentencia);
	if ($resent==null) {
		echo "Error de procesamieno no se han actuaizado los datos";
		echo '<script>alert("ERROR EN PROCESAMIENTO NO SE ACTUALIZARON LOS DATOS")</script> ';
		header("location: auditor.php");
		
		echo "<script>location.href='auditor.php'</script>";
	}else {
		echo '<script>alert("REGISTRO ACTUALIZADO")</script> ';
		
		echo "<script>location.href='auditor.php'</script>";

		
	}
?>
</body>
</html>