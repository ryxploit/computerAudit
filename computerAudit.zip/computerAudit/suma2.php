
<!DOCTYPE html>
<?php 

	
	session_start();
	 
	if (isset($_SESSION['proteccion']) && $_SESSION['proteccion'] == true) {
	 
	} else {
	   echo "Esta pagina es solo para usuarios registrados.<br>";
	   echo "<br><a href='login.php'>Login</a>";
	   exit;
	}
	?>
<html>
<head>
	<title></title>
</head>
<body>


<?php 


    include 'conexion.php';
   include 'suma3.php';
   
 $consulta = mysql_query("SELECT * FROM encuesta1 WHERE nombre = '$buscar'");
    $total1=0;
    while($row = mysql_fetch_array($consulta))
    {
      $total1 =  $row['p1_1'] + $row['p2_1'] + $row['p3_1'] + $row['p4_1'] + $row['p5_1'] + $row['p6_1'] + $row['p7_1'] + $row['p8_1']+ $row['p9_1']+ $row['p10_1']+ $row['p11_1']+ $row['p12_1']+ $row['p13_1']+ $row['p14_1']+ $row['p15_1'] ;
    }
   $total = $total1 + $total2;
    echo "<h1>resultado</h1>";
    echo $total;
     if ($total < 50) {
  echo "mal";
}elseif ($total > 50) {
	echo "exelente";
}
 ?>
 
</body>
</html>