<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="cssVerEncuesta2_admin/verEncuesta2_admin.css">
	<meta charset="utf-8">
	<title></title>
</head>
<body>
<?php
		extract($_GET);
		require("conexion.php");

		$sql="SELECT * FROM encuesta2 WHERE id=$id";
	
		$ressql=mysql_query($sql);
		while ($row=mysql_fetch_row ($ressql)){
		    	$id=$row[0];
		    	$auditor=$row[1];
		    	$nombre=$row[2];
		    	$p1_2=$row[3];
		    	$p2_2=$row[4];
		    	$p3_2=$row[5];
		    	$p4_2=$row[6];
		    	$p5_2=$row[7];
		    	$p6_2=$row[8];
		    	$p7_2=$row[9];
		    	$p8_2=$row[10];
		    	$p9_2=$row[11];
		    	$p10_2=$row[12];
		    	$p11_2=$row[13];
		    	$p12_2=$row[14];
		    	$p13_2=$row[15];
		    	$p14_2=$row[16];
		    	$p15_2=$row[17];
		    	
		    }



		?>
<form action="mostar_encuesta_admin.php" method="POST">
						Id<br><input class="no" type="text" name="id" value= "<?php echo $id ?>" readonly="readonly"><br>
                         <label>Auditor: </label>
						<input class="no" class="no" type="text" name="auditor" value="<?php echo $auditor ?>">
                         <br>
						<label>Nombre: </label>
						<input class="no" type="text" name="nombre" value="<?php echo $nombre ?>">
                         <br>
						<label>1. ¿Tiene ordenadores en su empresa?</label><br>
					<input type="radio" name="p1_2" value="3.8" <?php if ($p1_2 == '3.8') { echo "checked"; } ?>> Si
					<input type="radio" name="p1_2" value="0" <?php if ($p1_2 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>2.  ¿Utiliza su empresa dispositivos móviles, como tabletas, Blackberry, PDA, o
                    similares? </label><br>
					<input type="radio" name="p2_2" value="3.3" <?php if ($p2_2 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p2_2" value="0" <?php if ($p2_2 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>3.  ¿Utiliza su empresa software libre? </label><br>
					<input type="radio" name="p3_2" value="3.3" <?php if ($p3_2 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p3_2" value="0" <?php if ($p3_2 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>4. ¿Dispone su empresa de un ERP? (programa que le permite compartir información
                    entre todas las áreas funcionales, como contabilidad, gestión, almacén, personal, etc.) 
                    </label><br>
					<input type="radio" name="p4_2" value="3.3" <?php if ($p4_2 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p4_2" value="0" <?php if ($p4_2 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>5.  ¿Dispone su empresa de alguna aplicación informática específica para hacer un
                    seguimiento de su relación con los clientes? </label><br>
					<input type="radio" name="p5_2" value="3.3" <?php if ($p5_2 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p5_2" value="0" <?php if ($p5_2 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>6.  ¿Hay empleados de la empresa que, de manera regular, teletrabajan en su
                    domicilio, al menos media jornada semanal?</label><br>
					<input type="radio" name="p6_2" value="3.3" <?php if ($p6_2 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p6_2" value="0" <?php if ($p6_2 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>7. ¿Tiene su empresa conexión a Internet?¿Tiene su empresa conexión a Internet?</label><br>
					<input type="radio" name="p7_2" value="3.3" <?php if ($p7_2 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p7_2" value="0" <?php if ($p7_2 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>8.  ¿Utiliza su empresa correo electrónico? </label><br>
					<input type="radio" name="p8_2" value="3.3" <?php if ($p8_2 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p8_2" value="0" <?php if ($p8_2 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>9. ¿Utiliza Internet para relacionarse con la administración pública?</label><br>
					<input type="radio" name="p9_2" value="3.3" <?php if ($p9_2 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p9_2" value="0" <?php if ($p9_2 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>10.  ¿Utiliza su empresa firma electrónica? </label><br>
					<input type="radio" name="p10_2" value="3.3" <?php if ($p10_2 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p10_2" value="0" <?php if ($p10_2 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>11. ¿Tiene su empresa página web?</label><br>
					<input type="radio" name="p11_2" value="3.3" <?php if ($p11_2 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p11_2" value="0" <?php if ($p11_2 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>12.  ¿Realiza campañas publicitarias a través de Internet? </label><br>
					<input type="radio" name="p12_2" value="3.3" <?php if ($p12_2 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p12_2" value="0" <?php if ($p12_2 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>13.  ¿Utiliza las redes sociales con fines empresariales?</label><br>
					<input type="radio" name="p13_2" value="3.3" <?php if ($p13_2 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p13_2" value="0" <?php if ($p13_2 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>14.  ¿Envía su empresa facturas en formato electrónico?</label><br>
					<input type="radio" name="p14_2" value="3.3" <?php if ($p14_2 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p14_2" value="0" <?php if ($p14_2 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<label>15.  ¿Ha contratado o ha intentado contratar a un empleado con conocimientos TIC en el último año? </label><br>
					<input type="radio" name="p15_2" value="3.3" <?php if ($p15_2 == '3.3') { echo "checked"; } ?>> Si
					<input type="radio" name="p15_2" value="0" <?php if ($p15_2 == '0') { echo "checked"; } ?>> No<br>
					<br>
					<input href="mostar_encuesta_admin.php"class="bo" type="submit" name="" value="Regresar">
</form>

</body>
</html>