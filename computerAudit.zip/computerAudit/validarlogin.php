
<?php 

session_start();
	require 'conexion.php';
	$username=$_POST['usuario'];
	$pass=$_POST['contra'];


	//condicion de logeo de admin
	$sql2=mysql_query("SELECT * FROM login WHERE usuario='$username'");
	if($f2=mysql_fetch_assoc($sql2)){
		if($pass==$f2['admincontra']){
			$_SESSION['proteccion'] = true;
			$_SESSION['idusuario']=$f2['idusuario'];
			$_SESSION['usuario']=$f2['usuario'];
			

			
			echo "<script>location.href='administrador.php'</script>";
		
		}
	}
    //condicion de logeo de auditor
	$sql3=mysql_query("SELECT * FROM login WHERE usuario='$username'");
	if($f3=mysql_fetch_assoc($sql3)){
		if($pass==$f3['contraaudi']){
			 $_SESSION['proteccion'] = true;
             $_SESSION['idusuario']=$f3['idusuario'];
			 $_SESSION['usuario']=$f3['usuario'];
			

			
			echo "<script>location.href='auditor.php'</script>";
		
		}
	}
    //condicion de logeo de clientes
	$sql4=mysql_query("SELECT * FROM cliente WHERE usuario='$username'");
	if($f3=mysql_fetch_assoc($sql4)){
		if($pass==$f3['contrasena']){
			$_SESSION['proteccion'] = true;
			$_SESSION['idusuario']=$f3['idusuario'];
			$_SESSION['usuario']=$f3['usuario'];
			

			
			echo "<script>location.href='cliente.php'</script>";
		
		}
	}
	
    //condicion de loggeo de clintes normales
	$sql=mysql_query("SELECT * FROM login WHERE usuario='$username'");
	if($f=mysql_fetch_assoc($sql)){
		if($pass==$f['contraa']){
			$_SESSION['proteccion'] = true;
			$_SESSION['idusuario']=$f['idusuario'];
			$_SESSION['usuario']=$f['usuario'];
			

			header("Location: login.php");
		}else{
			echo '<script>alert("CONTRASEÑA INCORRECTA")</script> ';
		
			echo "<script>location.href='login.php'</script>";
		}
	}else{
		
		echo '<script>alert("ESTE USUARIO NO EXISTE, PORFAVOR REGISTRESE PARA PODER INGRESAR")</script> ';
		
		echo "<script>location.href='login.php'</script>";	

	}

















 ?>