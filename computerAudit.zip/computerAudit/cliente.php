
<!DOCTYPE html>
<?php 

	
	session_start();
	 
	if (isset($_SESSION['proteccion']) && $_SESSION['proteccion'] == true) {
	 
	} else {
	  // echo "Esta pagina es solo para usuarios registrados.<br>";
	   //echo "<br><a href='login.php'>Login</a>";
	   			echo "<script>location.href='login.php'</script>";

	   exit;
	}
	?>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="csscliente/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="csscliente/cliente.css">

	<link rel="stylesheet" href="fonts.css">
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>

	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>


<?php 


    include 'conexion.php';
   include 'suma3.php';

   
 $consulta = mysql_query("SELECT * FROM encuesta1 WHERE nombre = '$buscar'");
    $total1=0;
    while($row = mysql_fetch_array($consulta))
    {
      $total1 =  $row['p1_1'] + $row['p2_1'] + $row['p3_1'] + $row['p4_1'] + $row['p5_1'] + $row['p6_1'] + $row['p7_1'] + $row['p8_1']+ $row['p9_1']+ $row['p10_1']+ $row['p11_1']+ $row['p12_1']+ $row['p13_1']+ $row['p14_1']+ $row['p15_1'] ;
    }
   $total = $total1 + $total2;
   echo "<script type='text/javascript'>
function mostrar(){
document.getElementById('oculto').style.display = 'block';}
</script>";
   echo "<div id='oculto' style='display:none;'>";
    echo "<h1>Resultado</h1>";
    echo $total ;
     if ($total <= 50) {
  echo "<br>Tu auditoria no salio muy bien <br>";
  echo "<br><img src='imagenes/triste.png'>";
  
}elseif ($total <= 79) {
	echo "<br> Tu auditoria salio favorable <br>";
	echo "<br><img src='imagenes/sonriente.png'>";
}elseif ($total > 80) {
	echo "<br>Exelente, tu auditoria es muy favorable <br>";
	echo "<br><img src='imagenes/feliz.png'>";
}
echo "</div>";
 ?>
 
</body>
</html>