<!DOCTYPE html>
<?php
	
	session_start();
	 
	if (isset($_SESSION['proteccion']) && $_SESSION['proteccion'] == true) {
	 
	} else {
	  // echo "Esta pagina es solo para usuarios registrados.<br>";
	   //echo "<br><a href='login.php'>Login</a>";
               echo "<script>location.href='login.php'</script>";

	   exit;
	}

	
?>

<html>
<head>
	<meta charset="utf-8">
	<title>Auditoria informatica</title>
	<link rel="stylesheet" type="text/css" href="cssAuditor/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="cssAuditor/auditor.css">

	<link rel="stylesheet" href="fonts.css">
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>

	<meta name="viewport" content="width=device-width, initial-scale=1">


<body>
   <div class="col-md-12">
      <div class=" col-md-12 nonePadding nonePadding2">
      	   <div class="col-md-12 fondo icon">
      	   		<div class="col-md-3 icono"><img src="imagenes/logo01.png"></div>
      	   		<div class="col-md-2 title">
      	   			<a href="indexAuditoriaInformatica.html" class="link titulo"><strong>Auditoria Informatica</strong></a>
      	   		</div>
      	   		<div class="col-md-5"></div>
      	   		<div class="col-md-2 socialicon">
      	   			<div class="col-md-3 social">
      	   				<a href="http://facebook.com" class="icon-button facebook"><i class="icon-facebook"></i><span></span></a>
      	   			</div>
      	   			<div class="col-md-3">
      	   				<a href="http://twitter.com/minimalmonkey" class="icon-button twitter"><i class="icon-twitter"></i><span></span></a>
      	   			</div>
      	   			<div class="col-md-3">
      	   				<a href="http://plus.google.com" class="icon-button google-plus"><i class="icon-google-plus"></i><span></span></a>
      	   			</div>
      	   			<div class="col-md-3">
      	   				<a src="instagram.png" class="icon-button instagram"><i class="icon-instagram"></i><span></span></a>
      	   			</div>
      	   		</div>
      	   		<!--<div class="col-md-4 field">
      	   			<div class="col-md-3 uno">
      	   				
      	   			</div>
      	   			<div class="col-md-7 clear_pad">
      	   				<input class="form-control input" placeholder="Buscar"></input>
      	   			</div>
      	   			<div class="col-md-2 clear_pad"><button class="btn btn2">Buscar</button></div>
      	   		</div>-->
      	   </div>
      	</div>
      	   
      	<div class="col-md-12 icon2">
      		<div class="col-md-8 div_move">
				<ul class="nav">
					<div class="col-md-2 uls">
						<li><a href=""><span class="icon-profile"></span>Encuestas</a>
                     <ul>
                        <li><a href="encuesta1.php">Encuesta 1</a></li>
                        <li><a href="encuesta2.php">Encuesta 2</a></li>  
                     </ul>
                  </li>
					</div>
					<div class="col-md-2 uls">
						<li><a href=""><span class="icon-profile"></span>Registrar</a>
							<ul>
								<li><a href="altaclienteauditor.php">Clientes</a></li>	
							</ul>
						</li>
					</div>
					<div class="col-md-3 uls">
						<li><a href="indexAuditoriaInformatica.html"><span class="icon-info"></span>Auditoría Informática</a></li>
					</div>
					<div class="col-md-3 uls">
                  <li><a href="mostar_encuesta_admin.php"><span class="icon-profile"></span>Mostrar Encuestas</a>
					</div>
               <div class="col-md-2 uls">
                  <li><a href="mensajesad.php"><span class="icon-envelop"></span>Mensajes</a>
               </div>
				</ul>
			</div>
			<div class="col-md-2 div_move"></div>
      	   	<div class="col-md-2 login">
      	   		<li><a href="#">Bienvenido <?php echo $_SESSION['usuario'];?></a>
                     <ul>
                        <li><a href="cerrar_session.php">Cerrar sesion</a></li> 
                     </ul>
                </li>
      	   	</div>
		</div>
</div>

   <div class="col-md-12 "></div>
   	<div class="col-md-12">
   		<div class="col-md-2"></div>
   		<div class="col-md-8 nonePadding">
   			<div class="col-md-12 border shadow"  style="margin-bottom: 58px;">
   				<label class="lal">Bienvenido Auditor </label>
   			</div>
   		  <?php 

include 'conexion.php'; 
$sql5 = ("SELECT * FROM cliente");
$re = mysql_query($sql5);
echo "      
        <center><table border = 3 cellspadding = 3  cellspadding = 3 width='100%'>
            <tr bgcolor='#cccccc'>
            <th>Id</th>
            <th>Nombre</th>
            <th>Usuario</th>
            <th>Modificar</th>
            <th>Eliminar</th>
            </tr> ";
while ($arreglo = mysql_fetch_array($re)) {
   
         
             echo "<tr bgcolor='#d9edf7'>";
                  echo "<td><center>$arreglo[0]</center></td>";
                  echo "<td><center>$arreglo[1]</center></td>";
                  echo "<td><center>$arreglo[3]</center></td>";
            echo "<td><center><a href='actualizaraudi.php?id=$arreglo[0]'><img src='imagenes/actualizar_usuario.png' class='img-rounded'></center></td>"; 
         echo " <td><center><a href='auditor.php?id=$arreglo[0]&idborrar=2' onclick='return confirmar()'><img src='imagenes/usuario_borrar.png' class='img-rounded'/></a></center></td></tr>";
          
}
         

echo "</table></center>";
 
 extract($_GET);
               if(@$idborrar==2){
      
                  $sqlborrar="DELETE FROM cliente WHERE idusuario=$id";
                  $resborrar=mysql_query($sqlborrar);
                  echo '<script>alert("REGISTRO ELIMINADO")</script> ';
                  
                  echo "<script>location.href='auditor.php'</script>";
               }                 
 ?>
 <script>
function confirmar()
{
   if(confirm('¿Realmente desea eliminar?'))
      return true;
   else
      return false;
}
</script>
</body>
</html>