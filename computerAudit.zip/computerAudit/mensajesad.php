<!DOCTYPE html>
<html>
<head>
	<title>Mensajes de contactos</title>
</head>
<body>
<h1 align="center">Mensajes de contacto</h1>
<?php 

include 'conexion.php'; 
$sql6 = ("SELECT * FROM contacto");
$re = mysql_query($sql6);
if (!$re) { // add this check.
    die('Invalid query: ' . mysql_error());
}
echo "      
        <center><table border = 3 cellspadding = 3  cellspadding = 3 width='70%'>
            <tr bgcolor='#cccccc'>
            <th>Id</th>
            <th>Nombre</th>
            <th>Email</th>
            <th>Mensaje</th>
            <th>Eliminar</th>
            </tr> ";
while ($arreglo = mysql_fetch_array($re)) {
   
         
             echo "<tr bgcolor='#d9edf7'>";
                  echo "<td><center>$arreglo[0]</center></td>";
                  echo "<td><center>$arreglo[1]</center></td>";
                  echo "<td><center>$arreglo[2]</center></td>";
                  echo "<td><center>$arreglo[3]</center></td>";
                 
                  
           
         echo " <td><center><a href='mensajead.php?id=$arreglo[0]&idborrar=4'><img src='imagenes/cubo-de-basura.png' class='img-rounded'/></a></center></td></tr>";
          
}
         

echo "</table></center>";
 
 extract($_GET);
               if(@$idborrar==4){
      
                  $sqlborrar="DELETE FROM contacto WHERE id=$id";
                  $resborrar=mysql_query($sqlborrar);
                  echo '<script>alert("REGISTRO ELIMINADO")</script> ';
                  
                  echo "<script>location.href='administrador.php'</script>";
               }                 
 ?>
</body>
</html>