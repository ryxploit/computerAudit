<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="cssActualizarAdmin/actualizarAdmin.css">
	<meta charset="utf-8">
	<title>Actualizar usuario</title>
	<script type="text/javascript">
		function hideOrShowPassword(){ // Si quieres le cambias el nombre xD
    checkbox = document.getElementById('mos');
    passField = document.getElementById('id del campo de password');
    if(checkbox.checked==true) // Si la checkbox de mostrar contraseña está activada
    {
        passFiled.type = "text";
    }
    else // Si no está activada
    {
        passField.type = "password"
    }
}
	</script>
</head>
<body>
<h1 style="text-align: center; margin-bottom: 64px;">ACTUALIZAR USUARIO</h1>
<?php
		extract($_GET);
		require("conexion.php");

		$sql="SELECT * FROM login WHERE idusuario=$id";
	
		$ressql=mysql_query($sql);
		while ($row=mysql_fetch_row ($ressql)){
		    	$id=$row[0];
		    	$nombre=$row[1];
		    	$apellido=$row[2];
		    	$usuario=$row[3];
		    	$admincontra=$row[4];
		    	$contraaudi=$row[5];
		    	$fecha=$row[6];
		    }
		    ?>


		<form action="actuejecutar.php" method="post">
				Id<br><input type="text" name="id" value= "<?php echo $id ?>" readonly="readonly"><br>
				Nombre<br> <input type="text" name="nombre" value="<?php echo $nombre?>"><br>
				Apellido<br> <input type="text" name="apellido" value="<?php echo $apellido?>"><br>
				Usuario<br> <input type="text" name="usuario" value="<?php echo $usuario?>"><br>
				Administrador contraseña<br> <input id="password2" type="password" name="admincontra" value="<?php echo $admincontra?>">
				<label style="display: inline;">Ver Contraseña</label>
				<input style="width: 10%; margin-top: 5px; margin-bottom: 26px;" type="checkbox" onchange="document.getElementById('password2').type = this.checked ? 'text' : 'password'"><br>
				Contraseña Auditor<br> <input id="password1" type="password" name="contraaudi" value="<?php echo $contraaudi?>">
				<label style="display: inline;">Ver Contraseña</label>
				<input style="width: 10%; margin-top: 5px; margin-bottom: 26px;" type="checkbox" onchange="document.getElementById('password1').type = this.checked ? 'text' : 'password'"> <br>
				Fecha<br> <input type="date" name="fecha" value="<?php echo $fecha?>"><br>
				
				<br>
				<input type="submit" value="Actualizar">
			</form>
</body>
</html>