-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 20-12-2016 a las 13:37:29
-- Versión del servidor: 10.1.19-MariaDB
-- Versión de PHP: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `maestra`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `idusuario` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `apellido` varchar(30) NOT NULL,
  `usuario` varchar(30) NOT NULL,
  `contrasena` varchar(30) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`idusuario`, `nombre`, `apellido`, `usuario`, `contrasena`, `fecha`) VALUES
(4, 'Mario', 'Labrador Avila', 'mario', '23456', '2016-12-18'),
(5, 'rricardo', 'leva alcaraz', 'leva123', 'leva123', '2016-12-16');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contacto`
--

CREATE TABLE `contacto` (
  `id` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mensaje` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `contacto`
--

INSERT INTO `contacto` (`id`, `nombre`, `email`, `mensaje`) VALUES
(10, 'que', 'paso', 'ya'),
(11, 'jefa', '13', 'apa'),
(12, 'monica', 'mo@mo', 'monica'),
(13, 'gabriela', 'gabriela_ontiveros13@hotmail.c', 'paseme maestra :c');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `encuesta1`
--

CREATE TABLE `encuesta1` (
  `idencuesta1` int(11) NOT NULL,
  `auditor` varchar(30) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `p1_1` varchar(30) NOT NULL,
  `p2_1` varchar(30) NOT NULL,
  `p3_1` varchar(30) NOT NULL,
  `p4_1` varchar(30) NOT NULL,
  `p5_1` varchar(30) NOT NULL,
  `p6_1` varchar(30) NOT NULL,
  `p7_1` varchar(30) NOT NULL,
  `p8_1` varchar(30) NOT NULL,
  `p9_1` varchar(30) NOT NULL,
  `p10_1` varchar(30) NOT NULL,
  `p11_1` varchar(30) NOT NULL,
  `p12_1` varchar(30) NOT NULL,
  `p13_1` varchar(30) NOT NULL,
  `p14_1` varchar(30) NOT NULL,
  `p15_1` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `encuesta1`
--

INSERT INTO `encuesta1` (`idencuesta1`, `auditor`, `nombre`, `p1_1`, `p2_1`, `p3_1`, `p4_1`, `p5_1`, `p6_1`, `p7_1`, `p8_1`, `p9_1`, `p10_1`, `p11_1`, `p12_1`, `p13_1`, `p14_1`, `p15_1`) VALUES
(27, 'RODRIGEZ', 'telcel', '3.3', '0', '3.3', '0', '3.3', '0', '3.3', '0', '3.3', '0', '3.3', '0', '3.3', '0', '3.3'),
(29, 'MONICA', 'movistar', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'),
(31, 'monica', 'megacable', '3.8', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `encuesta2`
--

CREATE TABLE `encuesta2` (
  `id` int(11) NOT NULL,
  `auditor` varchar(30) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `p1_2` varchar(30) NOT NULL,
  `p2_2` varchar(30) NOT NULL,
  `p3_2` varchar(30) NOT NULL,
  `p4_2` varchar(30) NOT NULL,
  `p5_2` varchar(30) NOT NULL,
  `p6_2` varchar(30) NOT NULL,
  `p7_2` varchar(30) NOT NULL,
  `p8_2` varchar(30) NOT NULL,
  `p9_2` varchar(30) NOT NULL,
  `p10_2` varchar(30) NOT NULL,
  `p11_2` varchar(30) NOT NULL,
  `p12_2` varchar(30) NOT NULL,
  `p13_2` varchar(30) NOT NULL,
  `p14_2` varchar(30) NOT NULL,
  `p15_2` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `encuesta2`
--

INSERT INTO `encuesta2` (`id`, `auditor`, `nombre`, `p1_2`, `p2_2`, `p3_2`, `p4_2`, `p5_2`, `p6_2`, `p7_2`, `p8_2`, `p9_2`, `p10_2`, `p11_2`, `p12_2`, `p13_2`, `p14_2`, `p15_2`) VALUES
(5, 'perez', 'movistar', '3.3', '0', '3.3', '0', '3.3', '0', '3.3', '0', '3.3', '0', '3.3', '0', '3.3', '0', '3.3'),
(6, 'MONICA', 'telcel', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3'),
(8, 'monica', 'megacable', '3.8', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3', '3.3');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `login`
--

CREATE TABLE `login` (
  `idusuario` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `apellido` varchar(30) NOT NULL,
  `usuario` varchar(30) NOT NULL,
  `admincontra` varchar(30) NOT NULL,
  `contraaudi` varchar(30) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `login`
--

INSERT INTO `login` (`idusuario`, `nombre`, `apellido`, `usuario`, `admincontra`, `contraaudi`, `fecha`) VALUES
(1, 'Juan carlos', 'leon', 'carlos', '12345', '', '2016-12-05'),
(8, 'Monica', 'Oivarria', 'monica', '', '12345', '2016-12-17'),
(10, 'monica', 'olivarria', 'monyovarria', 'monica123', '', '2016-12-16');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`idusuario`);

--
-- Indices de la tabla `contacto`
--
ALTER TABLE `contacto`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `encuesta1`
--
ALTER TABLE `encuesta1`
  ADD PRIMARY KEY (`idencuesta1`);

--
-- Indices de la tabla `encuesta2`
--
ALTER TABLE `encuesta2`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`idusuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cliente`
--
ALTER TABLE `cliente`
  MODIFY `idusuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `contacto`
--
ALTER TABLE `contacto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT de la tabla `encuesta1`
--
ALTER TABLE `encuesta1`
  MODIFY `idencuesta1` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT de la tabla `encuesta2`
--
ALTER TABLE `encuesta2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT de la tabla `login`
--
ALTER TABLE `login`
  MODIFY `idusuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
