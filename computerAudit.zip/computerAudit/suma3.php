<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php 
include 'conexion.php';

include 'clientedesing.php';

$consulta = mysql_query("SELECT * FROM encuesta2 WHERE nombre = '$buscar'");
    $total2=0;
    while($row = mysql_fetch_array($consulta))
    {
      $total2 =  $row['p1_2'] + $row['p2_2'] + $row['p3_2'] + $row['p4_2'] + $row['p5_2'] + $row['p6_2'] + $row['p7_2'] + $row['p8_2']+ $row['p9_2']+ $row['p10_2']+ $row['p11_2']+ $row['p12_2']+ $row['p13_2']+ $row['p14_2']+ $row['p15_2'] ;
    }
    
 ?>
</body>
</html>