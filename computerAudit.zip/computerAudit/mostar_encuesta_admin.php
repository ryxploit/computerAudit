<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="cssMostarEncuestaAdmin/mostar_encuesta_admin.css">
    <meta charset="utf-8">
	<title>Encuestas</title>
</head>
<body>
<h1 align="center">RESULTADO DE ENCUESTA 1</h1>
<?php 
include 'conexion.php'; 
$sql6 = ("SELECT * FROM encuesta1");
$re = mysql_query($sql6);
echo "<form name='regresa' method='post' action='administrador.php'>";
echo "      
       <center> <table  border = 3 cellspadding = 3  cellspadding = 3 width='60%'>
            <tr bgcolor='#cccccc'>
            <th>Id</th>
            <th>Nombre</th>
            
            <th>Ver encuesta</th>
            <th>Eliminar</th>
		    </tr> ";
while ($arreglo = mysql_fetch_array($re)) {
	
         
             echo "<tr bgcolor='#d9edf7'>";
				    	echo "<td>$arreglo[0]</td>";
				    	echo "<td>$arreglo[1]</td>";
				    	
			echo "<td><center><a href='ver_encuesta_admin.php?id=$arreglo[0]'><img src='imagenes/encuesta.png' class='img-rounded'></center></td>"; 

			echo " <td><center><a href='mostar_encuesta_admin.php?id=$arreglo[0]&idborrar=3'><img src='imagenes/encuesta_borrar.png' /></a></center></td></tr>";
  }
		   

echo "</table></center>";
extract($_GET);
					if(@$idborrar==3){
		
						$sqlborrar="DELETE FROM encuesta1 WHERE idencuesta1=$id";
						$resborrar=mysql_query($sqlborrar);
						echo '<script>alert("REGISTRO ELIMINADO")</script> ';
						
						echo "<script>location.href='mostar_encuesta_admin.php'</script>";
					}                 

 ?>
 <h1 align="center">RESULTADO DE ENCUESTA 2</h1>
<?php 
include 'conexion.php'; 
$sql7 = ("SELECT * FROM encuesta2");
$ree = mysql_query($sql7);

echo "      
       <center> <table  border = 3 cellspadding = 3  cellspadding = 3 width='60%'>
            <tr bgcolor='#cccccc'>
            <th>Id</th>
            <th>Nombre</th>
            
            <th>Ver encuesta</th>
            <th>Eliminar</th>
		    </tr> ";
while ($arreglo = mysql_fetch_array($ree)) {
	
         
             echo "<tr bgcolor='#d9edf7'>";
				    	echo "<td>$arreglo[0]</td>";
				    	echo "<td>$arreglo[1]</td>";
				    	
			echo "<td><center><a href='ver_encuesta2_admin.php?id=$arreglo[0]'><img src='imagenes/encuesta.png' class='img-rounded'></center></td>"; 

			echo " <td><center><a href='mostar_encuesta_admin.php?id=$arreglo[0]&idborrar=4'><img src='imagenes/encuesta_borrar.png' /></a></center></td></tr>";
  }
		   

echo "</table></center>";
extract($_GET);
					if(@$idborrar==4){
		
						$sqlborrar="DELETE FROM encuesta2 WHERE id=$id";
						$resborrar=mysql_query($sqlborrar);
						echo '<script>alert("REGISTRO ELIMINADO")</script> ';
						
						echo "<script>location.href='mostar_encuesta_admin.php'</script>";
					}                 

 ?>
<br>
 <center><button style="width: 30%;">Regresar</button></center>
</body>
</html>