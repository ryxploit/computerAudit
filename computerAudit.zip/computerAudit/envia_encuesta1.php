<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php   

	include 'conexion.php';
	$auditor=$_POST['auditor'];
	$nombre=$_POST['nombre'];
	$p1_1=$_POST['p1_1'];
	$p2_1=$_POST['p2_1'];
	$p3_1=$_POST['p3_1'];
	$p4_1=$_POST['p4_1'];
	$p5_1=$_POST['p5_1'];
	$p6_1=$_POST['p6_1'];
	$p7_1=$_POST['p7_1'];
	$p8_1=$_POST['p8_1'];
	$p9_1=$_POST['p9_1'];
	$p10_1=$_POST['p10_1'];
	$p11_1=$_POST['p11_1'];
	$p12_1=$_POST['p12_1'];
	$p13_1=$_POST['p13_1'];
	$p14_1=$_POST['p14_1'];
	$p15_1=$_POST['p15_1'];
	
	$sql="INSERT INTO encuesta1(auditor,nombre,p1_1,p2_1,p3_1,
							p4_1,p5_1,p6_1,p7_1,p8_1,
							p9_1,p10_1,p11_1,p12_1,p13_1,
							p14_1,p15_1) VALUES('$auditor','$nombre','$p1_1','$p2_1','$p3_1','$p4_1'
					                             ,'$p5_1','$p6_1','$p7_1','$p8_1'
					                             ,'$p9_1','$p10_1' ,'$p11_1','$p12_1'
					                             ,'$p13_1','$p14_1','$p15_1')";
	
	$ejecutar=mysql_query($sql);
	
	if(!$ejecutar){
		echo"Hubo Algun Error";
	}else{
		
		echo "<script>location.href='auditor.php'</script>";
	}

	
?>   
</body>
</html>