<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php 
include 'conexion.php';

$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$usuario = $_POST['usuario'];
$cl = $_POST['contrasena'] ;
$fecha = $_POST['fecha'];


$sql12="INSERT INTO cliente(nombre,apellido,usuario,contrasena,fecha) VALUES ('$nombre','$apellido','$usuario','$cl',
                                                                                                    '$fecha')";

 $ejecutar = mysql_query($sql12);

 if (!$ejecutar) {
                   echo '<script>alert("hubo un error")</script>';
                         }
  else {
                   echo '<script>alert("REGISTRO GUARDADO")</script>';
                   echo "<script>location.href='administrador.php'</script>";
                  

                   }
                                                                                                                                                                                         





 ?>
</body>
</html>