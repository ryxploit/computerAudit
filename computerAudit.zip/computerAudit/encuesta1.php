<!DOCTYPE html>
<?php session_start(); ?>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="cssEncuesta1/encuesta1.css">
	<meta charset="utf-8">
	<title>Encuesta 1</title>
</head>
<body>
<form action="envia_encuesta1.php" method="POST">
                        <label>Auditor: </label>
						<input class="no" type="text" name="auditor" value="<?php echo $_SESSION['usuario'];?>" required placeholder="Ingresa el nombre del auditor">
                         <br>
						<label>Nombre: </label>
						<input class="no" type="text" name="nombre" placeholder="Ingresa tu nombre/empresa">
                         <br>
						<label>1. ¿El lugar donde se ubica el centro de cómputo esta seguro de inundaciones, robo o
					cualquier otra situación que pueda poner en peligro los equipos?</label><br>
					<input type="radio" name="p1_1" value="3.8" required> Si
					<input type="radio" name="p1_1" value="0" required> No<br>
					<br>
					<label>2. ¿El centro de cómputo da hacia el exterior?</label><br>
					<input type="radio" name="p2_1" value="3.3" required> Si
					<input type="radio" name="p2_1" value="0" required> No<br>
					<br>
					<label>3. ¿El material con que esta construido el centro de cómputo es confiable?</label><br>
					<input type="radio" name="p3_1" value="3.3" required> Si
					<input type="radio" name="p3_1" value="0" required> No<br>
					<br>
					<label>4. ¿Dentro del centro de cómputo existen materiales que puedan ser inflamables o
					causar algún daño a los equipos?</label><br>
					<input type="radio" name="p4_1" value="3.3" required> Si
					<input type="radio" name="p4_1" value="0" required> No<br>
					<br>
					<label>5. ¿Existe lugar suficiente para los equipos?</label><br>
					<input type="radio" name="p5_1" value="3.3" required> Si
					<input type="radio" name="p5_1" value="0" required> No<br>
					<br>
					<label>6. ¿Aparte del centro de cómputo se cuenta con algún lugar para almacenar otros
					equipos de cómputo, muebles, suministros, etc.?</label><br>
					<input type="radio" name="p6_1" value="3.3" required> Si
					<input type="radio" name="p6_1" value="0" required> No<br>
					<br>
					<label>7. ¿Se cuenta con una salida de emergencia?</label><br>
					<input type="radio" name="p7_1" value="3.3" required> Si
					<input type="radio" name="p7_1" value="0" required> No<br>
					<br>
					<label>8. ¿Existen señalamientos que las hagan visibles?</label><br>
					<input type="radio" name="p8_1" value="3.3" required> Si
					<input type="radio" name="p8_1" value="0" required> No<br>
					<br>
					<label>9. ¿Es adecuada la iluminación del centro de cómputo?</label><br>
					<input type="radio" name="p9_1" value="3.3" required> Si
					<input type="radio" name="p9_1" value="0" required> No<br>
					<br>
					<label>10. ¿El color de las paredes es adecuado para el centro de cómputo?</label><br>
					<input type="radio" name="p10_1" value="3.3" required> Si
					<input type="radio" name="p10_1" value="0" required> No<br>
					<br>
					<label>11. ¿Existen lámparas dentro del centro de cómputo?</label><br>
					<input type="radio" name="p11_1" value="3.3" required> Si
					<input type="radio" name="p11_1" value="0" required> No<br>
					<br>
					<label>12. ¿Es suficiente la iluminación del centro de cómputo?</label><br>
					<input type="radio" name="p12_1" value="3.3" required> Si
					<input type="radio" name="p12_1" value="0" required> No<br>
					<br>
					<label>13. ¿La temperatura a la que trabajan los equipos es la adecuada de acuerdo a las
					normas bajo las cuales se rige?</label><br>
					<input type="radio" name="p13_1" value="3.3" required> Si
					<input type="radio" name="p13_1" value="0" required> No<br>
					<br>
					<label>14. ¿Están limpios los ductos del aire acondicionado?</label><br>
					<input type="radio" name="p14_1" value="3.3" required> Si
					<input type="radio" name="p14_1" value="0" required> No<br>
					<br>
					<label>15. ¿La ubicación de los aires acondicionado es adecuada?</label><br>
					<input type="radio" name="p15_1" value="3.3" required> Si
					<input type="radio" name="p15_1" value="0" required> No<br>
					<br>
					<input class="bo" type="submit" name="" value="Enviar encuesta">

</form>
</body>
</html>