<!DOCTYPE html>
<?php

   
   session_start();
    
   if (isset($_SESSION['proteccion']) && $_SESSION['proteccion'] == true) {
    
   } else {
      //echo "Esta pagina es solo para usuarios registrados.<br>";
      //echo "<br><a href='login.php'>Login</a>";
               echo "<script>location.href='login.php'</script>";

      exit;
   }
?>
<html>
<head>
	<meta charset="utf-8">
	<title>Auditoria informatica</title>
	<link rel="stylesheet" type="text/css" href="cssAdministrador/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="cssAdministrador/administrador.css">

	<link rel="stylesheet" href="fonts.css">
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
<style type="text/css">
   
</style>
	<meta name="viewport" content="width=device-width, initial-scale=1">


<body>
   <div class="col-md-12">
      <div class=" col-md-12 nonePadding nonePadding2">
      	   <div class="col-md-12 fondo icon">
      	   		<div class="col-md-3 icono"><img src="imagenes/logo01.png"></div>
      	   		<div class="col-md-2 title">
      	   			<a href="#" class="link titulo"><strong>Auditoria Informatica</strong></a>
      	   		</div>
      	   		<div class="col-md-5"></div>
      	   		<div class="col-md-2 socialicon">
      	   			<div class="col-md-3 social">
      	   				<a href="http://facebook.com" class="icon-button facebook"><i class="icon-facebook"></i><span></span></a>
      	   			</div>
      	   			<div class="col-md-3">
      	   				<a href="http://twitter.com/minimalmonkey" class="icon-button twitter"><i class="icon-twitter"></i><span></span></a>
      	   			</div>
      	   			<div class="col-md-3">
      	   				<a href="http://plus.google.com" class="icon-button google-plus"><i class="icon-google-plus"></i><span></span></a>
      	   			</div>
      	   			<div class="col-md-3">
      	   				<a src="instagram.png" class="icon-button instagram"><i class="icon-instagram"></i><span></span></a>
      	   			</div>
      	   		</div>
      	   		<!--<div class="col-md-4 field">
      	   			<div class="col-md-3 uno">
      	   				
      	   			</div>
      	   			<div class="col-md-7 clear_pad">
      	   				<input class="form-control input" placeholder="Buscar"></input>
      	   			</div>
      	   			<div class="col-md-2 clear_pad"><button class="btn btn2">Buscar</button></div>
      	   		</div>-->
      	   </div>
      	</div>
      	   
      	<div class="col-md-12 icon2">
      		<div class="col-md-8 div_move">
				<ul class="nav">
					<div class="col-md-2 uls">
						<li><a href=""><span class="icon-profile"></span>Registrar</a>
							<ul>
								<li><a href="altacliente.php">Cliente</a></li>
								<li><a href="altaauditor.php">Auditor</a></li>
                        <li><a href="altaadmin.php">Administrador</a></li>	
							</ul>
						</li>
					</div>
					<div class="col-md-3 uls">
						<li><a href="mostar_encuesta_admin.php"><span class="icon-info"></span>Encuestas</a></li>
					</div>
					<div class="col-md-2 uls">
						<li><a href="mensajesad.php"><span class="icon-envelop"></span>Contacto</a></li>
					</div>
				</ul>
			</div>
			<div class="col-md-2 div_move"></div>
            <div class="col-md-2 login">
                  <li><a href="#">Bienvenido  <?php echo $_SESSION['usuario'];?></a>
                     <ul>
                        <li><a href="cerrar_session.php">Cerrar sesion</a></li> 
                     </ul>
                  </li>
            </div>
		</div>
</div>

	<div class="col-md-12 "></div>
   	<div class="col-md-12">
   		<div class="col-md-2"></div>
   		<div class="col-md-8 nonePadding">
   			<div class="col-md-12 border shadow">
   				<label class="lal">Bienvenido administrador  </label>
   			</div>
   			<h1 align="center"><strong>Auditores y Administradores</strong></h1>

<?php
include 'conexion.php'; 
$sql5 = ("SELECT * FROM login");
$rex = mysql_query($sql5);
echo "    
        <center><table border = 2 cellspadding = 3  cellspadding = 3 width='100%' >
            <tr bgcolor='#cccccc'>
            <th>Id</th>
            <th>Nombre</th>
            <th>Apellidos</th>
            <th>Usuario</th>
            
            <th>Fecha</th>
            <th>Modificar</th>
            <th>Eliminar</th>
            </tr> ";
while ($arreglo = mysql_fetch_array($rex)) {
   
         
             echo "<tr bgcolor='#d9edf7'>";
                  echo "<td><center>$arreglo[0]</center></td>";
                  echo "<td><center>$arreglo[1]</center></td>";
                  echo "<td><center>$arreglo[2]</center></td>";
                  echo "<td><center>$arreglo[3]</center></td>";
                 
                  echo "<td><center>$arreglo[6]</center></td>";
            echo "<td><center><a href='actualizaradmin.php?id=$arreglo[0]'><img src='imagenes/actualizar_usuario.png' class='img-rounded'></center></td>"; 
         echo " <td><center><a href='administrador.php?id=$arreglo[0]&idborrar=2' onclick='return confirmar()'><img src='imagenes/usuario_borrar.png' class='img-rounded'/></a></center></td></tr>";
          
}
         

echo "</table></center>";
 
 extract($_GET);
               if(@$idborrar==2){
      
                  $sqlborrar="DELETE FROM login WHERE idusuario=$id";
                  $resborrar=mysql_query($sqlborrar);
                  echo '<script>alert("REGISTRO ELIMINADO")</script> ';
                  
                  echo "<script>location.href='administrador.php'</script>";
               }                 
 ?>

 <h1 align="center"><strong>Listado de Clientes</strong></h1>
   <?php 

include 'conexion.php'; 
$sql5 = ("SELECT * FROM cliente");
$re = mysql_query($sql5);
echo "      
        <center><table border = 2 cellspadding = 3  cellspadding = 3 width='100%'>
            <tr bgcolor='#cccccc'>
            <th>Id</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Usuario</th>
            <th>Fecha</th>
            <th>Modificar</th>
            <th>Eliminar</th>
            </tr> ";
while ($arregloo = mysql_fetch_array($re)) {
   
         
             echo "<tr bgcolor='#d9edf7'>";
                  echo "<td><center>$arregloo[0]</center></td>";
                  echo "<td><center>$arregloo[1]</center></td>";
                  echo "<td><center>$arregloo[2]</center></td>";
                  echo "<td><center>$arregloo[3]</center></td>";
                  echo "<td><center>$arregloo[5]</center></td>";
            echo "<td ><center><a href='actualizaraudi2.php?id=$arregloo[0]'><img src='imagenes/actualizar_usuario.png' class='img-rounded'></center></td>"; 
         echo " <td><center><a href='administrador.php?id=$arregloo[0]&iddborrar=6' onclick='return confirmar()'><img src='imagenes/usuario_borrar.png' class='img-rounded'/></a></center></td></tr>";
          
}
         

echo "</table></center>";
 
 extract($_GET);
               if(@$iddborrar==6){
      
                  $sqllborrar="DELETE FROM cliente WHERE idusuario=$id";
                  $ressborrar=mysql_query($sqllborrar);
                  echo '<script>alert("REGISTRO ELIMINADO")</script> ';
                  
                  echo "<script>location.href='administrador.php'</script>";
               }                 
 ?>
  <script>
function confirmar()
{
   if(confirm('¿Realmente desea eliminar?'))
      return true;
   else
      return false;
}
</script>			
</body>
</html>