<!DOCTYPE html>

<html>
<head>
	<link rel="stylesheet" type="text/css" href="cssLoguin/login.css">
	<meta charset="utf-8">
	<title>Login</title>
</head>
<body>
<div align="center">
	<img src="imagenes/loginUser.png">
</div>
<form action="validarlogin.php" method="POST">
	<label>Usuario: </label>
	<input type="text" name="usuario" placeholder="Ingresa tu usuario"><br>
	<br>
	<label>Contraseña: </label>
    <input type="password" name="contra" placeholder="Ingresa tu password">
    <br>
    <input type="submit" value="Entrar">
</form>
</body>
</html>