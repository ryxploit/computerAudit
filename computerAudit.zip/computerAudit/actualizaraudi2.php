<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="cssActualizarAudi2/actualizarAudi2.css">
	<meta charset="utf-8">
	<title>Actualizar Usuario</title>
</head>
<body>
<h1 style="text-align: center; margin-bottom: 64px;">ACTUALIZAR USUARIO</h1>
<?php
		extract($_GET);
		require("conexion.php");

		$sql="SELECT * FROM cliente WHERE idusuario=$id";
	
		$ressql=mysql_query($sql);
		while ($row=mysql_fetch_row ($ressql)){
		    	$id=$row[0];
		    	$nombre=$row[1];
		    	$apellido=$row[2];
		    	$usuario=$row[3];
		    	$contra=$row[4];
		    	$fecha=$row[5];
		    }



		?>

		<form action="actuejecutar-audi2.php" method="post">
				Id<br><input type="text" name="id" value= "<?php echo $id ?>" readonly="readonly"><br>
				Nombre<br> <input type="text" name="nombre" value="<?php echo $nombre?>"><br>
				Apellido<br> <input type="text" name="apellido" value="<?php echo $apellido?>"><br>
				Usuario<br> <input type="text" name="usuario" value="<?php echo $usuario?>"><br>
				Contraseña Cliente<br> <input id="password4" type="password" name="contra" value="<?php echo $contra?>">
				<label style="display: inline;">Ver Contraseña</label>
				<input style="width: 10%; margin-top: 5px; margin-bottom: 26px;" type="checkbox" onchange="document.getElementById('password4').type = this.checked ? 'text' : 'password'">
				<br>
				Fecha<br> <input type="date" name="fecha" value="<?php echo $fecha?>"><br>
				
				<br>
				<input type="submit" value="Actualizar">
			</form>
</body>
</html>