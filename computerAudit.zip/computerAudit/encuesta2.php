<!DOCTYPE html>
<?php session_start(); ?>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="cssEncuesta2/encuesta2.css">
	<meta charset="utf-8">
	<title>Encuesta 1</title>
</head>
<body>
<form action="envia_encuesta2.php" method="POST">
                       <label>Auditor: </label>
						<input class="no" type="text" name="auditor" value="<?php echo $_SESSION['usuario'];?>" placeholder="Ingresa el nombre del auditor">
                         <br>
						<label>Nombre: </label>
						<input class="no" type="text" name="nombre" required placeholder="Ingresa tu nombre/empresa">
                         <br>
						<label>1. ¿Tiene ordenadores en su empresa?</label><br>
					<input type="radio" name="p1_2" value="3.8" required> Si
					<input type="radio" name="p1_2" value="0" required> No<br>
					<br>
					<label>2.  ¿Utiliza su empresa dispositivos móviles, como tabletas, Blackberry, PDA, o
                    similares? </label><br>
					<input type="radio" name="p2_2" value="3.3" required> Si
					<input type="radio" name="p2_2" value="0" required> No<br>
					<br>
					<label>3.  ¿Utiliza su empresa software libre? </label><br>
					<input type="radio" name="p3_2" value="3.3" required> Si
					<input type="radio" name="p3_2" value="0" required> No<br>
					<br>
					<label>4. ¿Dispone su empresa de un ERP? (programa que le permite compartir información
                    entre todas las áreas funcionales, como contabilidad, gestión, almacén, personal, etc.) 
                    </label><br>
					<input type="radio" name="p4_2" value="3.3" required> Si
					<input type="radio" name="p4_2" value="0" required> No<br>
					<br>
					<label>5.  ¿Dispone su empresa de alguna aplicación informática específica para hacer un
                    seguimiento de su relación con los clientes? </label><br>
					<input type="radio" name="p5_2" value="3.3" required> Si
					<input type="radio" name="p5_2" value="0" required> No<br>
					<br>
					<label>6.  ¿Hay empleados de la empresa que, de manera regular, teletrabajan en su
                    domicilio, al menos media jornada semanal?</label><br>
					<input type="radio" name="p6_2" value="3.3" required> Si
					<input type="radio" name="p6_2" value="0" required> No<br>
					<br>
					<label>7. ¿Tiene su empresa conexión a Internet?¿Tiene su empresa conexión a Internet?</label><br>
					<input type="radio" name="p7_2" value="3.3" required> Si
					<input type="radio" name="p7_2" value="0" required> No<br>
					<br>
					<label>8.  ¿Utiliza su empresa correo electrónico? </label><br>
					<input type="radio" name="p8_2" value="3.3" required> Si
					<input type="radio" name="p8_2" value="0" required> No<br>
					<br>
					<label>9. ¿Utiliza Internet para relacionarse con la administración pública?</label><br>
					<input type="radio" name="p9_2" value="3.3" required> Si
					<input type="radio" name="p9_2" value="0" required> No<br>
					<br>
					<label>10.  ¿Utiliza su empresa firma electrónica? </label><br>
					<input type="radio" name="p10_2" value="3.3" required> Si
					<input type="radio" name="p10_2" value="0" required> No<br>
					<br>
					<label>11. ¿Tiene su empresa página web?</label><br>
					<input type="radio" name="p11_2" value="3.3" required> Si
					<input type="radio" name="p11_2" value="0" required> No<br>
					<br>
					<label>12.  ¿Realiza campañas publicitarias a través de Internet? </label><br>
					<input type="radio" name="p12_2" value="3.3" required> Si
					<input type="radio" name="p12_2" value="0" required> No<br>
					<br>
					<label>13.  ¿Utiliza las redes sociales con fines empresariales?</label><br>
					<input type="radio" name="p13_2" value="3.3" required> Si
					<input type="radio" name="p13_2" value="0" required> No<br>
					<br>
					<label>14.  ¿Envía su empresa facturas en formato electrónico?</label><br>
					<input type="radio" name="p14_2" value="3.3" required> Si
					<input type="radio" name="p14_2" value="0" required> No<br>
					<br>
					<label>15.  ¿Ha contratado o ha intentado contratar a un empleado con conocimientos TIC en el últimoaño? </label><br>
					<input type="radio" name="p15_2" value="3.3" required> Si
					<input type="radio" name="p15_2" value="0" required> No<br>
					<br>
					<input class="bo" type="submit" name="" value="Enviar encuesta">

</form>
</body>
</html>