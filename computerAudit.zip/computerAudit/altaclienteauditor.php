<!DOCTYPE html>
<?php 

	
	session_start();
	 
	if (isset($_SESSION['proteccion']) && $_SESSION['proteccion'] == true) {
	 
	} else {
	   echo "Esta pagina es solo para usuarios registrados.<br>";
	   echo "<br><a href='login.php'>Login</a>";
	   exit;
	}
 ?>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="cssAltaCliente/cliente.css">
	<meta charset="utf-8">
	<title>Alta de cliente</title>
</head>
<body>
<h1 style="text-align: center; margin-bottom: 64px;">REGISTRO DE CLIENTES</h1>
<form action="guardarclienteauditor.php" method="POST">
	<label>Nombre</label>
	<input type="text" name="nombre">
	<br>
	<label>Apellido</label>
	<input type="text" name="apellido">
	<br>
	<label>Usuario</label>
	<input type="text" name="usuario">
	<br>
	
	<br>
	<label>Contraseña Cliente</label>
	<input type="password" name="contrasena" id="password6" >

	<label style="display: inline;">Ver Contraseñas</label>
	<input style="width: 10%; margin-top: 5px; margin-bottom: 26px;" type="checkbox" onchange="document.getElementById('password6').type = this.checked ? 'text' : 'password'">
	<br>
	<label>Fecha</label>
	<input type="date" name="fecha" value="<?php echo date("Y-m-d"); ?>">
	<br>
	<input type="submit"  value="Guardar">

</form>
</body>
</html> 