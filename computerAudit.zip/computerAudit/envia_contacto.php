﻿<html>   

<head>   
<title>Contacto</title>   
</head>   

<body>   
<?php   
//conectamos Con el servidor
	include 'conexion.php';
	//recuperar las variables
	
	$nombre=$_POST['nombre'];
	$email=$_POST['email'];
	$mensaje=$_POST['mensaje'];
	//hacemos la sentencia de sql
	$sql="INSERT INTO contacto(nombre,email,mensaje) VALUES('$nombre','$email','$mensaje')";
	//ejecutamos la sentencia de sql
	$ejecutar=mysql_query($sql);
	//verificamos la ejecucion
	if(!$ejecutar){
		echo"Hubo Algun Error";
	}else{
		echo '<script>alert(" Gracias nos pondremos en contacto")</script>';
		echo"<script>location.href='cliente.php'</script>";
	}

?>   
</body>   

</html>  