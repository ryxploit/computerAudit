<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php   

	include 'conexion.php';
	$auditor=$_POST['auditor'];
	$nombre=$_POST['nombre'];
	$p1_2=$_POST['p1_2'];
	$p2_2=$_POST['p2_2'];
	$p3_2=$_POST['p3_2'];
	$p4_2=$_POST['p4_2'];
	$p5_2=$_POST['p5_2'];
	$p6_2=$_POST['p6_2'];
	$p7_2=$_POST['p7_2'];
	$p8_2=$_POST['p8_2'];
	$p9_2=$_POST['p9_2'];
	$p10_2=$_POST['p10_2'];
	$p11_2=$_POST['p11_2'];
	$p12_2=$_POST['p12_2'];
	$p13_2=$_POST['p13_2'];
	$p14_2=$_POST['p14_2'];
	$p15_2=$_POST['p15_2'];
	
	$sql="INSERT INTO encuesta2(auditor,nombre,p1_2,p2_2,p3_2,
						p4_2,p5_2,p6_2,p7_2,
						p8_2,p9_2,p10_2,p11_2,
						p12_2,p13_2,p14_2,p15_2) VALUES('$auditor','$nombre','$p1_2','$p2_2' ,'$p3_2','$p4_2'
					                                    ,'$p5_2','$p6_2' ,'$p7_2','$p8_2' ,'$p9_2','$p10_2'
					                                     ,'$p11_2','$p12_2','$p13_2','$p14_2','$p15_2')";
	
	$ejecutar=mysql_query($sql);
	
	if(!$ejecutar){
		echo"Hubo Algun Error";
	}else{
		
		echo "<script>location.href='auditor.php'</script>";
	}

	
?>   
</body>
</html>